package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.DAO;
import util.Validador;
import java.awt.Cursor;

@SuppressWarnings("unused")
public class Login extends JFrame {
	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblStatus;
	private JTextField txtLogin;
	private JLabel lblNewLabel_1;
	private JPasswordField txtSenha;
	private JLabel lblNewLabel_2;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Login() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				status();
			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/img/logo128.png")));
		setTitle("Lava Rápido Vinicius - Login");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 368, 253);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));


		setLocationRelativeTo(null);

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnLogin = new JButton("Acessar");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logar();
			}
		});
		btnLogin.setBounds(223, 180, 89, 23);
		contentPane.add(btnLogin);

		lblStatus = new JLabel("");
		lblStatus.setIcon(new ImageIcon(Login.class.getResource("/img/dboff.png")));
		lblStatus.setBounds(10, 155, 48, 48);
		contentPane.add(lblStatus);

		txtLogin = new JTextField();
		txtLogin.setBounds(52, 26, 144, 17);
		contentPane.add(txtLogin);
		txtLogin.setColumns(10);
		txtLogin.setColumns(10);
	
		txtLogin.setDocument(new Validador(20));

		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(10, 28, 46, 14);
		contentPane.add(lblNewLabel);

		lblNewLabel_1 = new JLabel("Senha");
		lblNewLabel_1.setBounds(10, 56, 46, 14);
		contentPane.add(lblNewLabel_1);

		txtSenha = new JPasswordField();
		txtSenha.setBounds(52, 54, 144, 17);
		contentPane.add(txtSenha);
		txtSenha.setDocument(new Validador(250));
		
       
		getRootPane().setDefaultButton(btnLogin);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Login.class.getResource("/img/carro.png")));
		lblNewLabel_2.setBounds(100, 104, 242, 65);
		contentPane.add(lblNewLabel_2);
	}

	
	private void status() {
		
		try {

			con = dao.conectar();
			if (con == null) {
		
				lblStatus.setIcon(new ImageIcon(Login.class.getResource("/img/dboff.png")));
			} else {
				lblStatus.setIcon(new ImageIcon(Login.class.getResource("/img/dbon.png")));
			}
		
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	

	private void logar() {
		
	
		String capturaSenha = new String(txtSenha.getPassword());
		
	

	
		if (txtLogin.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o login");
			txtLogin.requestFocus();
		} else if (capturaSenha.length() == 0 ) {
			JOptionPane.showMessageDialog(null, "Digite a senha");
			txtSenha.requestFocus();
		} else {
	
			String read = "select * from usuarios where login=? and senha=md5(?)";
			try {
			
				con = dao.conectar();
			
				pst = con.prepareStatement(read);
				pst.setString(1, txtLogin.getText());
				pst.setString(2, capturaSenha);
			

				rs = pst.executeQuery();
				
				if (rs.next()) {
		
					String perfil = rs. getString(5);
				
					if (perfil.equals("admin")){
			
						
				
						Principal principal = new Principal();
				
						principal.btnRelatorio.setEnabled(true);
						principal.btnUsuarios.setEnabled(true);
						principal.setVisible(true);
				
						principal.panelRodape.setBackground(Color.BLUE);
				
						principal.lblUsuario.setText(rs.getString(2));
						
					
						this.dispose();
					}else {
					
						
				
						Principal principal = new Principal();
						principal.setVisible(true);
					
						principal.lblUsuario.setText(rs.getString(2));
						
					
						this.dispose();
					}
				
				} else {
					JOptionPane.showMessageDialog(null, "Usuário e/ou senha inválidos(s)");
				}
				
				con.close();

			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}

}
