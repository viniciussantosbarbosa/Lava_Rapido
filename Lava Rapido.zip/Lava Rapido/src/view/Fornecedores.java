package view;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import model.DAO;
import util.Validador;

import java.awt.event.ActionListener;
import java.net.URL;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

@SuppressWarnings("serial")
public class Fornecedores extends JDialog {
	
	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	private final JPanel contentPanel = new JPanel();
	private JTextField txtRazao;
	private JTextField txtEmail;
	private JTextField txtCnpj;
	private JTextField txtTelefone;
	private JTextField txtSite;
	private JTextField txtCep;
	private JTextField txtEndereco;
	private JTextField txtNumero;
	private JTextField txtBairro;
	private JTextField txtCidade;
	private JTextField txtID;
	private JTextField txtComplemento;
	@SuppressWarnings("rawtypes")
	private JComboBox cboUf;
	private JButton btnBuscar;
	private JButton btnCep;
	private JButton btnAdicionar;
	private JButton btnEditar;
	private JButton btnLimpar;
	private JButton btnExcluir;
	private JScrollPane scrollPane;
	@SuppressWarnings("rawtypes")
	private JList listarFornecedor;


	public static void main(String[] args) {
		try {
			Fornecedores dialog = new Fornecedores();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Fornecedores() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Fornecedores.class.getResource("/img/carro pqn.png")));
		setTitle("Lava Rápido Vinicius - Fornecedores");
		setBounds(100, 100, 600, 430);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setVisible(false);
		scrollPane.setBounds(136, 52, 184, 104);
		contentPanel.add(scrollPane);
		
		listarFornecedor = new JList();
		scrollPane.setViewportView(listarFornecedor);
		listarFornecedor.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarFornecedorLista();
			}
		});
		scrollPane.setViewportView(listarFornecedor);
		{
			JLabel lblNewLabel = new JLabel("Nome / Razão social:");
			lblNewLabel.setBounds(10, 37, 135, 14);
			contentPanel.add(lblNewLabel);
		}
		
		txtRazao = new JTextField();
		txtRazao.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				listarFornecedor();
			}
			@Override
			public void keyTyped(KeyEvent e) {
				
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtRazao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarFornecedor();
			}
		});
		txtRazao.setBounds(136, 34, 184, 20);
		contentPanel.add(txtRazao);
		txtRazao.setColumns(10);
		txtRazao.setDocument (new Validador(30));
		
		JLabel lblNewLabel_1 = new JLabel("ID:");
		lblNewLabel_1.setBounds(10, 11, 46, 14);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Email:");
		lblNewLabel_2.setBounds(10, 62, 46, 14);
		contentPanel.add(lblNewLabel_2);
		
		txtEmail = new JTextField();
		txtEmail.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtEmail.setBounds(49, 62, 271, 20);
		contentPanel.add(txtEmail);
		txtEmail.setColumns(10);
		txtEmail.setDocument (new Validador(30));
		
		JLabel lblNewLabel_3 = new JLabel("CNPJ:");
		lblNewLabel_3.setBounds(10, 94, 46, 14);
		contentPanel.add(lblNewLabel_3);
		
		txtCnpj = new JTextField();
		txtCnpj.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
	
				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtCnpj.setBounds(49, 91, 271, 20);
		contentPanel.add(txtCnpj);
		txtCnpj.setColumns(10);
		txtCnpj.setDocument (new Validador(30));
		
		JLabel lblNewLabel_4 = new JLabel("Telefone:");
		lblNewLabel_4.setBounds(10, 281, 67, 14);
		contentPanel.add(lblNewLabel_4);
		
		txtTelefone = new JTextField();
		txtTelefone.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {

				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtTelefone.setBounds(69, 278, 127, 20);
		contentPanel.add(txtTelefone);
		txtTelefone.setColumns(10);
		txtTelefone.setDocument (new Validador(30));
		
		JLabel lblNewLabel_5 = new JLabel("Site:");
		lblNewLabel_5.setBounds(10, 119, 46, 14);
		contentPanel.add(lblNewLabel_5);
		
		txtSite = new JTextField();
		txtSite.setBounds(37, 117, 272, 20);
		contentPanel.add(txtSite);
		txtSite.setColumns(10);
		txtSite.setDocument (new Validador(30));
		
		JLabel lblNewLabel_6 = new JLabel("CEP:");
		lblNewLabel_6.setBounds(5, 142, 46, 14);
		contentPanel.add(lblNewLabel_6);
		
		txtCep = new JTextField();
		txtCep.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtCep.setBounds(39, 144, 271, 20);
		contentPanel.add(txtCep);
		txtCep.setColumns(10);
		txtCep.setDocument (new Validador(30));
		
		JLabel lblNewLabel_7 = new JLabel("Endereço:");
		lblNewLabel_7.setBounds(10, 171, 62, 14);
		contentPanel.add(lblNewLabel_7);
		
		txtEndereco = new JTextField();
		txtEndereco.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {

				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtEndereco.setBounds(69, 168, 251, 20);
		contentPanel.add(txtEndereco);
		txtEndereco.setColumns(10);
		txtEndereco.setDocument (new Validador(30));
		
		JLabel lblNewLabel_8 = new JLabel("Número:");
		lblNewLabel_8.setBounds(10, 199, 62, 14);
		contentPanel.add(lblNewLabel_8);
		
		txtNumero = new JTextField();
		txtNumero.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtNumero.setBounds(59, 196, 251, 20);
		contentPanel.add(txtNumero);
		txtNumero.setColumns(10);
		txtNumero.setDocument (new Validador(30));
		
		JLabel lblNewLabel_9 = new JLabel("Complemento:");
		lblNewLabel_9.setBounds(214, 281, 106, 14);
		contentPanel.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Bairro:");
		lblNewLabel_10.setBounds(10, 226, 46, 14);
		contentPanel.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Cidade:");
		lblNewLabel_11.setBounds(10, 251, 51, 14);
		contentPanel.add(lblNewLabel_11);
		
		txtBairro = new JTextField();
		txtBairro.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
			
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtBairro.setBounds(59, 223, 251, 20);
		contentPanel.add(txtBairro);
		txtBairro.setColumns(10);
		txtBairro.setDocument (new Validador(30));
		
		txtCidade = new JTextField();
		txtCidade.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
	
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtCidade.setBounds(59, 248, 251, 20);
		contentPanel.add(txtCidade);
		txtCidade.setColumns(10);
		txtCidade.setDocument (new Validador(30));
		
		cboUf = new JComboBox();
		cboUf.setModel(new DefaultComboBoxModel(new String[] {"", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"}));
		cboUf.setBounds(350, 247, 46, 22);
		contentPanel.add(cboUf);
		
		JLabel lblNewLabel_12 = new JLabel("UF:");
		lblNewLabel_12.setBounds(320, 251, 46, 14);
		contentPanel.add(lblNewLabel_12);
		
		txtID = new JTextField();
		txtID.setEditable(false);
		txtID.setBounds(33, 6, 86, 20);
		contentPanel.add(txtID);
		txtID.setColumns(10);
		
		txtComplemento = new JTextField();
		txtComplemento.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
			
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtComplemento.setBounds(302, 278, 117, 20);
		contentPanel.add(txtComplemento);
		txtComplemento.setColumns(10);
		txtComplemento.setDocument (new Validador(30));
		
		btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarFornecedor();
			}
		});
		btnAdicionar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAdicionar.setContentAreaFilled(false);
		btnAdicionar.setBorder(null);
		btnAdicionar.setIcon(new ImageIcon(Fornecedores.class.getResource("/img/adicionar.png")));
		btnAdicionar.setToolTipText("Adicionar");
		btnAdicionar.setBounds(49, 322, 48, 48);
		contentPanel.add(btnAdicionar);
		
		btnEditar = new JButton("");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarFornecedor();	
			}
		});
		btnEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnEditar.setBorder(null);
		btnEditar.setContentAreaFilled(false);
		btnEditar.setIcon(new ImageIcon(Fornecedores.class.getResource("/img/editar.png")));
		btnEditar.setToolTipText("Editar");
		btnEditar.setBounds(107, 322, 48, 48);
		contentPanel.add(btnEditar);
		
		btnExcluir = new JButton("");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 excluirFornecedor();
			}
		});
		btnExcluir.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnExcluir.setContentAreaFilled(false);
		btnExcluir.setBorder(null);
		btnExcluir.setIcon(new ImageIcon(Fornecedores.class.getResource("/img/excluir contato.png")));
		btnExcluir.setToolTipText("Excluir");
		btnExcluir.setBounds(165, 322, 48, 48);
		contentPanel.add(btnExcluir);
		
		btnLimpar = new JButton("");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpar();
			}
		});
		btnLimpar.setBorder(null);
		btnLimpar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimpar.setContentAreaFilled(false);
		btnLimpar.setIcon(new ImageIcon(Fornecedores.class.getResource("/img/limpar (2).png")));
		btnLimpar.setToolTipText("Limpar");
		btnLimpar.setBounds(248, 322, 48, 48);
		contentPanel.add(btnLimpar);
		
		btnBuscar = new JButton("");
		btnBuscar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBuscar.setBorder(null);
		btnBuscar.setContentAreaFilled(false);
		btnBuscar.setIcon(new ImageIcon(Fornecedores.class.getResource("/img/search pqn.png")));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarFornecedor();
			}
		});
		btnBuscar.setBounds(320, 21, 48, 48);
		contentPanel.add(btnBuscar);
		
		btnCep = new JButton("");
		btnCep.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnCep.setContentAreaFilled(false);
		btnCep.setBorder(null);
		btnCep.setIcon(new ImageIcon(Fornecedores.class.getResource("/img/check 2.png")));
		btnCep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarCep();
			}
		});
		btnCep.setBounds(320, 138, 51, 23);
		contentPanel.add(btnCep);
		
		JLabel lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setToolTipText("Fornecedores");
		lblNewLabel_13.setIcon(new ImageIcon(Fornecedores.class.getResource("/img/products.png")));
		lblNewLabel_13.setBounds(422, 37, 128, 128);
		contentPanel.add(lblNewLabel_13);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
	
	
	private void adicionarFornecedor() {


		if (txtRazao.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a Razão social / nome");
			txtRazao.requestFocus();
		} else if (txtEmail.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o email!");
			txtEmail.requestFocus();
		} else if (txtCnpj.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o CNPJ!");
			txtCnpj.requestFocus();
		} else if (txtSite.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o site!");
			txtSite.requestFocus();
		} else if (txtCep.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o cep!");
			txtCep.requestFocus();
		}else if (txtNumero.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o numero!");
			txtNumero.requestFocus();
		}else if (txtTelefone.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o telefone!");
			txtTelefone.requestFocus();
		} else {

		
			String create = "insert into fornecedores (razao,email,cnpj,site,cep,endereco,numero,bairro,cidade,telefone,complemento,uf) values (?,?,?,?,?,?,?,?,?,?,?,?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);

				pst.setString(1, txtRazao.getText());
				pst.setString(2, txtEmail.getText());
				pst.setString(3, txtCnpj.getText());
				pst.setString(4, txtSite.getText());
				pst.setString(5, txtCep.getText());
				pst.setString(6, txtEndereco.getText());
				pst.setString(7, txtNumero.getText());
				pst.setString(8, txtBairro.getText());
				pst.setString(9, txtCidade.getText());
				pst.setString(10, txtTelefone.getText());
				pst.setString(11, txtComplemento.getText());
				pst.setString(12, cboUf.getSelectedItem().toString());
				pst.executeUpdate();

				
				JOptionPane.showMessageDialog(null, "Fornecedor adicionado com sucesso!");
				

				Limpar();
				con.close();
		
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
	}
	
	
	private void buscarFornecedor() {

		String read = "select * from fornecedores where razao = ?";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(read);
			pst.setString(1, txtRazao.getText());
			rs = pst.executeQuery();
			if (rs.next()) {
				
				txtID.setText(rs.getString(1));
				txtRazao.setText(rs.getString(2));
				txtEmail.setText(rs.getString(3));
				txtCnpj.setText(rs.getString(4));
				txtSite.setText(rs.getString(5));
				txtCep.setText(rs.getString(6));
				txtEndereco.setText(rs.getString(7));
				txtNumero.setText(rs.getString(8));
				txtBairro.setText(rs.getString(9));
				txtCidade.setText(rs.getString(10));
				txtTelefone.setText(rs.getString(11));
				txtComplemento.setText(rs.getString(12));
				cboUf.setSelectedItem(rs.getString(13));

		

				btnAdicionar.setEnabled(false);

				btnBuscar.setEnabled(false);

				btnEditar.setEnabled(true);
				btnExcluir.setEnabled(true);

			} else {
				JOptionPane.showMessageDialog(null, "Fornecedor não cadastrado!");

				btnAdicionar.setEnabled(true);

				btnBuscar.setEnabled(false);

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		

	}
	
	private void buscarFornecedorLista() {

		int linha = listarFornecedor.getSelectedIndex();

		if (linha >= 0) {
			System.out.println(linha);

			String read2 = "select * from fornecedores where razao like '" + txtRazao.getText() + "%'"
					+ "order by razao limit " + (linha) + " , 1";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(read2);
				rs = pst.executeQuery();
				if (rs.next()) {
				
					scrollPane.setVisible(false);

					txtID.setText(rs.getString(1));
					txtRazao.setText(rs.getString(2));
					txtEmail.setText(rs.getString(3));
					txtCnpj.setText(rs.getString(4));
					txtSite.setText(rs.getString(5));
					txtCep.setText(rs.getString(6));
					txtEndereco.setText(rs.getString(7));
					txtNumero.setText(rs.getString(8));
					txtBairro.setText(rs.getString(9));
					txtCidade.setText(rs.getString(10));
					txtTelefone.setText(rs.getString(11));
					txtComplemento.setText(rs.getString(12));
					cboUf.setSelectedItem(rs.getString(13));

			
				} else {
					System.out.println("Fornecedor não cadastrado");
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		} else {
	
			scrollPane.setVisible(false);
		}
	}
	
	@SuppressWarnings("unchecked")
	private void listarFornecedor() {
		
		DefaultListModel<String> modelo = new DefaultListModel<>();
		listarFornecedor.setModel(modelo);
	
		String readLista = "select * from fornecedores where razao like '" + txtRazao.getText() + "%'" + "order by razao";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(readLista);
			rs = pst.executeQuery();
		
			while (rs.next()) {
			
				scrollPane.setVisible(true);
				
				modelo.addElement(rs.getString(2));
				
				if (txtRazao.getText().isEmpty()) {
					scrollPane.setVisible(false);
				}
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	

	private void editarFornecedor() {
	

		if (txtRazao.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a razão social!");
			txtRazao.requestFocus();

		} else if (txtEmail.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o email!!");
			txtEmail.requestFocus();

		} else if (txtCnpj.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o cnpj");
			txtCnpj.requestFocus();

		} else {

			String update = "update fornecedores set razao=?,email=?,cnpj=?,site=?,cep=?,endereco=?,numero=?,bairro=?,cidade=?,telefone=?,Complemento=?,uf=? where idfor=? ";
			try {
				con = dao.conectar();

				pst = con.prepareStatement(update);

				pst.setString(1, txtRazao.getText());
				pst.setString(2, txtEmail.getText());
				pst.setString(3, txtCnpj.getText());
				pst.setString(4, txtSite.getText());
				pst.setString(5, txtCep.getText());
				pst.setString(6, txtEndereco.getText());
				pst.setString(7, txtNumero.getText());
				pst.setString(8, txtBairro.getText());
				pst.setString(9, txtCidade.getText());
				pst.setString(10, txtTelefone.getText());
				pst.setString(11, txtComplemento.getText());
				pst.setString(12, cboUf.getSelectedItem().toString());
				
				pst.setString(13, txtID.getText());

				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Dados do fornecedor alterados com sucesso!");
				con.close();
				Limpar();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}
	
	
	private void buscarCep() {
		String logradouro = "";
		String tipoLogradouro = "";
		String cep = txtCep.getText();
		String resultado = null;
		try {
			URL url = new URL("http://cep.republicavirtual.com.br/web_cep.php?cep=" + cep + "&formato=xml");
			SAXReader xml = new SAXReader();
			Document documento = xml.read(url);
			Element root = documento.getRootElement();
			for (Iterator<Element> it = root.elementIterator(); it.hasNext();) {
				Element element = it.next();
				if (element.getQualifiedName().equals("cidade")) {
					txtCidade.setText(element.getText());
				}
				if (element.getQualifiedName().equals("bairro")) {
					txtBairro.setText(element.getText());
				}
				if (element.getQualifiedName().equals("uf")) {
					cboUf.setSelectedItem(element.getText());
				}
				if (element.getQualifiedName().equals("tipo_logradouro")) {
					tipoLogradouro = element.getText();
				}
				if (element.getQualifiedName().equals("logradouro")) {
					logradouro = element.getText();
				}
				if (element.getQualifiedName().equals("resultado")) {
					resultado = element.getText();
				
					if (resultado.equals("0")) {
						JOptionPane.showMessageDialog(null, "CEP inexistente!");
					}

				}

			}

			txtEndereco.setText(tipoLogradouro + " " + logradouro);
		} catch (

		Exception e) {
			System.out.println(e);
		}
	}
	
	private void excluirFornecedor() { 

		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste fornecedor?", "ATENÇÃO!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from fornecedores where idfor=?";
			try {

				con = dao.conectar();

				pst = con.prepareStatement(delete);
				pst.setString(1, txtID.getText());
				pst.executeUpdate();

				Limpar();
				JOptionPane.showMessageDialog(null, "Fornecedor excluido!");

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
	
	private void Limpar() {
		txtID.setText(null);
		txtRazao.setText(null);
		txtTelefone.setText(null);
		txtEndereco.setText(null);
		txtCep.setText(null);
		txtBairro.setText(null);
		txtEmail.setText(null);
		txtCnpj.setText(null);
		txtSite.setText(null);
		txtCep.setText(null);
		txtCidade.setText(null);
		txtNumero.setText(null);
		txtComplemento.setText(null);
		cboUf.setSelectedItem("");

		btnAdicionar.setEnabled(false);
		btnEditar.setEnabled(false);
		btnBuscar.setEnabled(true);
		btnExcluir.setEnabled(false);
		txtRazao.requestFocus();

	}
}
