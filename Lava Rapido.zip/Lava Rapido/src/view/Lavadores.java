package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.DAO;
import util.Validador;
import java.awt.Cursor;

public class Lavadores extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtNome;
	private JTextField txtTelefone;
	private JTextField txtRg;
	
	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;
	private JTextField txtID;
	private JButton btnAdicionar;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JButton btnLimpar;
	private JButton btnBuscar;
	@SuppressWarnings("rawtypes")
	private JList listarFuncionarios;
	private JScrollPane scrollPane;

	
	public static void main(String[] args) {
		try {
			Lavadores dialog = new Lavadores();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@SuppressWarnings("rawtypes")
	public Lavadores() {
		setTitle("Lava Rápido Vinicius - Lavadores");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Lavadores.class.getResource("/img/carro pqn.png")));
		setBounds(100, 100, 496, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			btnAdicionar = new JButton("Adicionar");
			btnAdicionar.setToolTipText("Adicionar");
			btnAdicionar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					adicionarFuncionario();
				}
			});
			
			scrollPane = new JScrollPane();
			scrollPane.setVisible(false);
			scrollPane.setBounds(51, 48, 116, 23);
			contentPanel.add(scrollPane);
			
			listarFuncionarios = new JList();
			listarFuncionarios.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					buscarFucionariosLista();
				}
			});
			scrollPane.setViewportView(listarFuncionarios);
			btnAdicionar.setBounds(35, 217, 89, 23);
			contentPanel.add(btnAdicionar);
		}
		{
			btnEditar = new JButton("Editar");
			btnEditar.setToolTipText("Editar");
			btnEditar.setEnabled(false);
			btnEditar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					editarFuncionario();
				}
			});
			btnEditar.setBounds(134, 217, 89, 23);
			contentPanel.add(btnEditar);
		}
		{
			btnExcluir = new JButton("Excluir");
			btnExcluir.setToolTipText("Excluir");
			btnExcluir.setEnabled(false);
			btnExcluir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					excluirFuncionario();
				}
			});
			btnExcluir.setBounds(233, 217, 89, 23);
			contentPanel.add(btnExcluir);
		}
		{
			btnLimpar = new JButton("Limpar");
			btnLimpar.setToolTipText("Limpar");
			btnLimpar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Limpar();
				}
			});
			btnLimpar.setBounds(369, 217, 89, 23);
			contentPanel.add(btnLimpar);
		}
		{
			JLabel lblNewLabel = new JLabel("Nome:");
			lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
			lblNewLabel.setBounds(10, 32, 61, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Telefone:");
			lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
			lblNewLabel_1.setBounds(10, 57, 61, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			JLabel lblNewLabel_2 = new JLabel("Rg:");
			lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
			lblNewLabel_2.setBounds(10, 79, 46, 23);
			contentPanel.add(lblNewLabel_2);
		}
		
		txtNome = new JTextField();
		txtNome.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				listarFuncionarios();
			}
			@Override
			public void keyTyped(KeyEvent e) {
				
				String caracteres = "0987654321.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtNome.setBounds(51, 30, 116, 20);
		contentPanel.add(txtNome);
		txtNome.setColumns(10);
		txtNome.setDocument(new Validador(30));
		txtNome.setDocument (new Validador(30));
		
		txtTelefone = new JTextField();
		txtTelefone.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
	
				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtTelefone.setBounds(61, 55, 106, 20);
		contentPanel.add(txtTelefone);
		txtTelefone.setColumns(10);
		txtTelefone.setDocument(new Validador(30));
		txtTelefone.setDocument (new Validador(30));
		
		txtRg = new JTextField();
		txtRg.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321-..";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtRg.setBounds(35, 81, 132, 20);
		contentPanel.add(txtRg);
		txtRg.setColumns(10);
		txtRg.setDocument(new Validador(30));
		txtRg.setDocument (new Validador(30));
		{
			txtID = new JTextField();
			txtID.setEditable(false);
			txtID.setBounds(384, 11, 86, 20);
			contentPanel.add(txtID);
			txtID.setColumns(10);
		}
		{
			JLabel lblNewLabel_3 = new JLabel("ID:");
			lblNewLabel_3.setBounds(363, 14, 46, 14);
			contentPanel.add(lblNewLabel_3);
		}
		{
			btnBuscar = new JButton("");
			btnBuscar.setToolTipText("Buscar");
			btnBuscar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnBuscar.setBorder(null);
			btnBuscar.setContentAreaFilled(false);
			btnBuscar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					buscarFuncionario();
				}
			});
			btnBuscar.setIcon(new ImageIcon(Lavadores.class.getResource("/img/search pqn.png")));
			btnBuscar.setBounds(167, 30, 56, 25);
			contentPanel.add(btnBuscar);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
	
	private void adicionarFuncionario() {

	

		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o nome do funcionario!");
			txtNome.requestFocus();
		} else if (txtTelefone.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o telefone do funcionario!");
			txtTelefone.requestFocus();
		}else if (txtRg.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o rg do funcionario!");
			txtRg.requestFocus();
		}  else {
		

	
			String create = "insert into lavadores (nome,rg,telefone) values(?,?,?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);
				pst.setString(1, txtNome.getText());
				pst.setString(2, txtTelefone.getText());
				pst.setString(3, txtRg.getText());
				
	
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Funcionario adicionado com sucesso!");
				Limpar();
				con.close();

				
			} catch (Exception e) {
				System.out.println(e);
			} 
		}
			
 }
	

	private void buscarFuncionario() {

		String read = "select * from lavadores where nome = ?";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(read);
			pst.setString(1, txtNome.getText());
			rs = pst.executeQuery();
			if (rs.next()) {
				txtID.setText(rs.getString(1));
				txtNome.setText(rs.getString(2));
				txtTelefone.setText(rs.getString(3));
				txtRg.setText(rs.getString(4));


				btnAdicionar.setEnabled(false);

				btnBuscar.setEnabled(false);

				btnEditar.setEnabled(true);
				btnExcluir.setEnabled(true);

			} else {
				JOptionPane.showMessageDialog(null, "Funcionario não cadastrado!");

				btnAdicionar.setEnabled(true);

				btnBuscar.setEnabled(false);

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	private void buscarFucionariosLista() {
	
		int linha = listarFuncionarios.getSelectedIndex();
	
		if (linha >= 0) {
			System.out.println(linha);
			
			String read2 = "select * from lavadores where nome like '" + txtNome.getText() + "%'" + "order by nome limit " + (linha) + " , 1";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(read2);
				rs = pst.executeQuery();
				if  (rs.next()) {
					
					scrollPane.setVisible(false);
					txtID.setText(rs.getString(1));
					txtNome.setText(rs.getString(2));
					txtTelefone.setText(rs.getString(3));
					txtRg.setText(rs.getString(4));
					
					btnAdicionar.setEnabled(false);

					btnBuscar.setEnabled(false);

					btnEditar.setEnabled(true);
					btnExcluir.setEnabled(true);
					
				
	
				} else  {
					System.out.println("Funcionario não cadastrado");
					
					btnAdicionar.setEnabled(true);

					btnBuscar.setEnabled(false);
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		} else {
			
			scrollPane.setVisible(false);
		}
	}
	
	@SuppressWarnings("unchecked")
	private void listarFuncionarios() {

		DefaultListModel<String> modelo = new DefaultListModel<>();
		listarFuncionarios.setModel(modelo);

		String readLista = "select * from lavadores where nome like '" + txtNome.getText() + "%'" + "order by nome";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(readLista);
			rs = pst.executeQuery();
		
			while (rs.next()) {
				
				scrollPane.setVisible(true);
			
				modelo.addElement(rs.getString(2));
			
				if (txtNome.getText().isEmpty()) {
					scrollPane.setVisible(false);
				}
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	
	
	private void editarFuncionario() {
		

		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o nome do cliente!");
			txtNome.requestFocus();
		}
		if (txtTelefone.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o telefone do funcionario!");
			txtTelefone.requestFocus();
		}
		if (txtRg.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o rg do Funcionario!");
			txtRg.requestFocus();
		}else {

			String update = "update lavadores set nome=?,telefone=?,rg=? where idlav=? ";
			try {
				con = dao.conectar();

				pst = con.prepareStatement(update);

				pst.setString(1, txtNome.getText());
				pst.setString(2, txtTelefone.getText());
				pst.setString(3, txtRg.getText());
				pst.setString(4, txtID.getText());

				pst.executeUpdate();
				Limpar();
				JOptionPane.showMessageDialog(null, "Dados do funcionario editados com sucesso");
				con.close();
		
			} catch (java.sql.SQLIntegrityConstraintViolationException e2) {
				JOptionPane.showMessageDialog(null,
						"Cliente não adicionado.\nJá possui um veículo cadatrastado com a mesma placa.");
			} catch (Exception e2) {
				System.out.println(e2);

			}

		}

	}
	
	private void excluirFuncionario() {
		

		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste Cliente?", "ATENÇÃO!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from lavadores where idlav=?";
			try {

				con = dao.conectar();

				pst = con.prepareStatement(delete);
				pst.setString(1, txtID.getText());
				pst.executeUpdate();

				Limpar();
				JOptionPane.showMessageDialog(null, "Funcionario excluído");
				
			} catch (java.sql.SQLIntegrityConstraintViolationException e1) {
					JOptionPane.showMessageDialog(null, "Não é possível excluir esse cliente pois ele possui uma OS em aberto!");
					txtNome.setText(null);
					txtNome.requestFocus();

			} catch (Exception e1) {
				System.out.println(e1);
			}
		}
	}
	
	private void Limpar() {
		txtID.setText(null);
		txtNome.setText(null);
		txtTelefone.setText(null);
		txtRg.setText(null);
	

		btnAdicionar.setEnabled(false);
		btnEditar.setEnabled(false);
		btnBuscar.setEnabled(true);
		btnExcluir.setEnabled(false);
		txtNome.requestFocus();

	}
}

