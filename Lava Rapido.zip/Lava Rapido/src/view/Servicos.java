package view;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.toedter.calendar.JDateChooser;

import model.DAO;
import util.Validador;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

@SuppressWarnings("serial")
public class Servicos extends JDialog {

	
	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	private final JPanel contentPanel = new JPanel();
	private JTextField txtPlaca;
	private JTextField txtValor;
	private JTextField txtOS;
	private JTextField txtIDCli;
	private JTextField txtModelo;
	private JTextField txtCor;
	private JButton btnAdicionar;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JButton btnlimpar;
	private JDateChooser txtDataOS;
	private JPanel panel_1;
	private JLabel lblNewLabel_14;
	private JTextField txtNomeCli;
	private JTextField txtUsuario;



	public String usuario;
	private JLabel lblNewLabel_16;
	private JTextField txtObservacao;
	private JButton btnOSI;
	@SuppressWarnings("rawtypes")
	private JList listarClientes;
	private JScrollPane scrollPane;
	private JTextField txtNomeLav;
	private JTextField txtIDLav;
	@SuppressWarnings("rawtypes")
	private JList listarLavadores;
	private JScrollPane scrollPaneLav;
	@SuppressWarnings("rawtypes")
	private JComboBox cboLavagem;
	private JButton btnOS;

	
	public static void main(String[] args) {
		try {
			Servicos dialog = new Servicos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Servicos() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Servicos.class.getResource("/img/carro pqn.png")));
		setTitle("Lava Rápido Vinicius - Serviços");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				txtUsuario.setText(usuario);
			}
		});
		setBounds(100, 100, 692, 495);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Veiculo:");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(34, 88, 46, 14);
		contentPanel.add(lblNewLabel_1);

		txtModelo = new JTextField();
		txtModelo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {

				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtModelo.setBounds(109, 86, 133, 20);
		contentPanel.add(txtModelo);
		txtModelo.setColumns(10);
		txtModelo.setDocument (new Validador(30));

		JLabel lblNewLabel_2 = new JLabel("Cor do veiculo:");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(24, 30, 101, 14);
		contentPanel.add(lblNewLabel_2);

		txtCor = new JTextField();
		txtCor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtCor.setBounds(109, 28, 133, 20);
		contentPanel.add(txtCor);
		txtCor.setColumns(10);
		txtCor.setDocument (new Validador(30));

		JLabel lblNewLabel_3 = new JLabel("Placa:");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(34, 55, 46, 14);
		contentPanel.add(lblNewLabel_3);

		txtPlaca = new JTextField();
		txtPlaca.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
			}
		});
		txtPlaca.setBounds(109, 55, 133, 20);
		contentPanel.add(txtPlaca);
		txtPlaca.setColumns(10);
		txtPlaca.setDocument (new Validador(30));

		JLabel lblNewLabel_5 = new JLabel("Tipo de lavagem:");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_5.setBounds(10, 117, 101, 18);
		contentPanel.add(lblNewLabel_5);

		JLabel lblNewLabel_7 = new JLabel("Valor:");
		lblNewLabel_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(484, 328, 46, 14);
		contentPanel.add(lblNewLabel_7);

		txtValor = new JTextField();
		txtValor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtValor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		txtValor.setBounds(530, 328, 68, 20);
		contentPanel.add(txtValor);
		txtValor.setColumns(10);
		txtValor.setDocument (new Validador(10));

		JLabel lblNewLabel_8 = new JLabel("OS:");
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(254, 30, 46, 14);
		contentPanel.add(lblNewLabel_8);

		txtOS = new JTextField();
		txtOS.setEditable(false);
		txtOS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txtOS.setBounds(277, 28, 71, 20);
		contentPanel.add(txtOS);
		txtOS.setColumns(10);

		btnAdicionar = new JButton("");
		btnAdicionar.setToolTipText("Adicionar");
		btnAdicionar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAdicionar.setBorder(null);
		btnAdicionar.setContentAreaFilled(false);
		btnAdicionar.setIcon(new ImageIcon(Servicos.class.getResource("/img/adicionar.png")));
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarOS();
			}
		});
		btnAdicionar.setBounds(239, 377, 48, 48);
		contentPanel.add(btnAdicionar);

		btnEditar = new JButton("");
		btnEditar.setToolTipText("Editar");
		btnEditar.setEnabled(false);
		btnEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnEditar.setBorder(null);
		btnEditar.setContentAreaFilled(false);
		btnEditar.setIcon(new ImageIcon(Servicos.class.getResource("/img/editar.png")));
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarOS();
			
			}
		});
		btnEditar.setBounds(297, 377, 48, 48);
		contentPanel.add(btnEditar);

		btnExcluir = new JButton("");
		btnExcluir.setToolTipText("Excluir");
		btnExcluir.setEnabled(false);
		btnExcluir.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnExcluir.setBorder(null);
		btnExcluir.setContentAreaFilled(false);
		btnExcluir.setIcon(new ImageIcon(Servicos.class.getResource("/img/excluir contato.png")));
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirOS();
			}
		});
		btnExcluir.setBounds(345, 377, 48, 48);
		contentPanel.add(btnExcluir);

		btnlimpar = new JButton("");
		btnlimpar.setToolTipText("Limpar");
		btnlimpar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnlimpar.setContentAreaFilled(false);
		btnlimpar.setBorder(null);
		btnlimpar.setIcon(new ImageIcon(Servicos.class.getResource("/img/limpar (2).png")));
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpar();
			}
		});
		btnlimpar.setBounds(433, 377, 48, 48);
		contentPanel.add(btnlimpar);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}

		txtDataOS = new JDateChooser();
		txtDataOS.setEnabled(false);
		txtDataOS.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txtDataOS.setBounds(310, 59, 133, 20);
		contentPanel.add(txtDataOS);

		JLabel lblNewLabel_10 = new JLabel("Data OS:");
		lblNewLabel_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_10.setBounds(252, 61, 48, 14);
		contentPanel.add(lblNewLabel_10);

		panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Clientes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(453, 31, 214, 98);
		contentPanel.add(panel_1);
		panel_1.setLayout(null);

		scrollPane = new JScrollPane();
		scrollPane.setVisible(false);
		scrollPane.setBounds(26, 40, 138, 27);
		panel_1.add(scrollPane);

		listarClientes = new JList();
		scrollPane.setViewportView(listarClientes);
		listarClientes.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarClientesLista();
			}
		});
		scrollPane.setViewportView(listarClientes);

		txtIDCli = new JTextField();
		txtIDCli.setEditable(false);
		txtIDCli.setBounds(78, 67, 86, 20);
		panel_1.add(txtIDCli);
		txtIDCli.setColumns(10);

		JLabel lblNewLabel_9 = new JLabel("ID:");
		lblNewLabel_9.setBounds(58, 70, 46, 14);
		panel_1.add(lblNewLabel_9);

		lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.setToolTipText("Buscar");
		lblNewLabel_14.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_14.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		lblNewLabel_14.setBounds(156, 11, 48, 48);
		panel_1.add(lblNewLabel_14);

		txtNomeCli = new JTextField();
		txtNomeCli.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				listarClientes();
			}
		});
		txtNomeCli.setBounds(26, 23, 138, 20);
		panel_1.add(txtNomeCli);
		txtNomeCli.setColumns(10);

		JLabel lblNewLabel_15 = new JLabel("Usuario:");
		lblNewLabel_15.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_15.setBounds(530, 13, 46, 14);
		contentPanel.add(lblNewLabel_15);

		txtUsuario = new JTextField();
		txtUsuario.setEditable(false);
		txtUsuario.setBounds(575, 11, 92, 20);
		contentPanel.add(txtUsuario);
		txtUsuario.setColumns(10);

		lblNewLabel_16 = new JLabel("Observação:");
		lblNewLabel_16.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		lblNewLabel_16.setBounds(24, 323, 76, 23);
		contentPanel.add(lblNewLabel_16);

		txtObservacao = new JTextField();
		txtObservacao.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtObservacao.setBounds(24, 349, 205, 76);
		contentPanel.add(txtObservacao);
		txtObservacao.setColumns(10);
		txtObservacao.setDocument (new Validador(30));

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Servicos.class.getResource("/img/valor.png")));
		lblNewLabel.setBounds(608, 316, 48, 48);
		contentPanel.add(lblNewLabel);

		btnOS = new JButton("");
		btnOS.setBorder(null);
		btnOS.setContentAreaFilled(false);
		btnOS.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		btnOS.setToolTipText("Buscar OS");
		btnOS.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnOS.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarOS();
			}
		});
		btnOS.setBounds(345, 13, 48, 48);
		contentPanel.add(btnOS);

		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon(Servicos.class.getResource("/img/carro pqn.png")));
		lblNewLabel_6.setBounds(109, 326, 31, 20);
		contentPanel.add(lblNewLabel_6);

		btnOSI = new JButton("");
		btnOSI.setEnabled(false);
		btnOSI.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnOSI.setBorder(null);
		btnOSI.setContentAreaFilled(false);
		btnOSI.setIcon(new ImageIcon(Servicos.class.getResource("/img/impressora.png")));
		btnOSI.setToolTipText("Imprimir");
		btnOSI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imprimirOS();
			}
		});
		btnOSI.setBounds(581, 387, 48, 48);
		contentPanel.add(btnOSI);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Lavadores", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(453, 145, 214, 86);
		contentPanel.add(panel);
		panel.setLayout(null);

		txtNomeLav = new JTextField();
		txtNomeLav.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				listarLavadores();
			}
		});

		scrollPaneLav = new JScrollPane();
		scrollPaneLav.setVisible(false);
		scrollPaneLav.setBounds(30, 38, 134, 23);
		panel.add(scrollPaneLav);

		listarLavadores = new JList();
		scrollPane.setViewportView(listarClientes);
		listarLavadores.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarLavadoresLista();
			}
		});
		scrollPaneLav.setViewportView(listarLavadores);
		txtNomeLav.setBounds(30, 18, 134, 20);
		panel.add(txtNomeLav);
		txtNomeLav.setColumns(10);

		JButton btnNewButton = new JButton("");
		btnNewButton.setToolTipText("Buscar");
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setBorder(null);
		btnNewButton.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		btnNewButton.setBounds(158, 18, 56, 28);
		panel.add(btnNewButton);

		JLabel lblNewLabel_4 = new JLabel("ID:");
		lblNewLabel_4.setBounds(64, 61, 46, 14);
		panel.add(lblNewLabel_4);

		txtIDLav = new JTextField();
		txtIDLav.setEditable(false);
		txtIDLav.setBounds(88, 57, 76, 20);
		panel.add(txtIDLav);
		txtIDLav.setColumns(10);
		
		cboLavagem = new JComboBox();
		cboLavagem.setModel(new DefaultComboBoxModel(new String[] {"", "Ducha simples", "Ducha com cera", "Ducha com cera e pretinho", "Ducha completa com aspiração"}));
		cboLavagem.setBounds(109, 116, 191, 22);
		contentPanel.add(cboLavagem);
	}


	private void adicionarOS() {

	
		if (txtCor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a cor do veiculo!");
			txtCor.requestFocus();
		} else if (txtPlaca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a placa do veiculo!");
			txtPlaca.requestFocus();
		} else if (txtModelo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o fabricante/modelo do veiculo!");
			txtModelo.requestFocus();
		} else if (txtNomeCli.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o nome do cliente!");
			txtNomeCli.requestFocus();
		} else if (txtNomeLav.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o nome do Funcionario!");
			txtNomeLav.requestFocus();
		}else if (txtValor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o valor do serviço!");
			txtValor.requestFocus();
		} else {

		
			String create = "insert into servicos (corveiculo,placaveiculo,modeloveiculo,tipodelavagem,valor,observacao,idcli,idlav,usuario) values (?,?,?,?,?,?,?,?,?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);

				pst.setString(1, txtCor.getText());
				pst.setString(2, txtPlaca.getText());
				pst.setString(3, txtModelo.getText());
				pst.setString(4, cboLavagem.getSelectedItem().toString());
				pst.setString(5, txtValor.getText());
				pst.setString(6, txtObservacao.getText());
				pst.setString(7, txtIDCli.getText());
				pst.setString(8, txtIDLav.getText());
				pst.setString(9, txtUsuario.getText());
				pst.executeUpdate();

				
				JOptionPane.showMessageDialog(null, "Ordem de Serviço gerada com susesso!");
				
				recuperarOS();
				btnOSI.setEnabled(true);
				Limpar();
				con.close();
		
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		
		
	}

	private void buscarOS() {
	
		String numOS = JOptionPane.showInputDialog("Número da OS");
		
		String read = "select * from servicos where os = ?";
		try {
		
			con = dao.conectar();
			pst = con.prepareStatement(read);
			pst.setString(1, numOS);
			rs = pst.executeQuery();
			if (rs.next()) {
				txtOS.setText(rs.getString(1));
				txtCor.setText(rs.getString(2));
				txtPlaca.setText(rs.getString(3));
				txtModelo.setText(rs.getString(4));
				cboLavagem.setSelectedItem(rs.getString(5));
				txtValor.setText(rs.getString(6));
			
				String setarData = rs.getString(7);
	
				Date dataFormatada = new SimpleDateFormat("yyyy-MM-dd").parse(setarData);
				txtDataOS.setDate(dataFormatada);
	
				txtObservacao.setText(rs.getString(8));
				txtIDCli.setText(rs.getString(9));
				txtIDLav.setText(rs.getString(10));

				btnAdicionar.setEnabled(false);
				btnEditar.setEnabled(true);
				btnExcluir.setEnabled(true);
				btnOSI.setEnabled(true);

			} else {
				JOptionPane.showMessageDialog(null, "Ordem Serviço inexistente!");
				btnAdicionar.setEnabled(true);
			}

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	private void buscarClientesLista() {

		int linha = listarClientes.getSelectedIndex();
	
		if (linha >= 0) {
			System.out.println(linha);
			
			String read2 = "select * from clientes where nome like '" + txtNomeCli.getText() + "%'"
					+ "order by nome limit " + (linha) + " , 1";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(read2);
				rs = pst.executeQuery();
				if (rs.next()) {
					
					scrollPane.setVisible(false);

					txtIDCli.setText(rs.getString(1));
					txtNomeCli.setText(rs.getString(2));

				} else {
					System.out.println("usuário não cadastrado");
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		} else {
		
			scrollPane.setVisible(false);
		}
	}

	private void buscarLavadoresLista() {
		
		int linha = listarLavadores.getSelectedIndex();
	
		if (linha >= 0) {
			System.out.println(linha);
	
			String read2 = "select * from lavadores where nome like '" + txtNomeLav.getText() + "%'"
					+ "order by nome limit " + (linha) + " , 1";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(read2);
				rs = pst.executeQuery();
				if (rs.next()) {
				
					scrollPaneLav.setVisible(false);

					txtIDLav.setText(rs.getString(1));
					txtNomeLav.setText(rs.getString(2));

				
				} else {
					System.out.println("Funcionario não cadastrado");
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		} else {
		
			scrollPaneLav.setVisible(false);
		}
	}


	@SuppressWarnings("unchecked")
	private void listarLavadores() {

		DefaultListModel<String> modelo = new DefaultListModel<>();
		listarLavadores.setModel(modelo);

		String readLista = "select * from lavadores where nome like '" + txtNomeLav.getText() + "%'" + "order by nome";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(readLista);
			rs = pst.executeQuery();
	
			while (rs.next()) {
	
				scrollPaneLav.setVisible(true);
			
				modelo.addElement(rs.getString(2));
				
				if (txtNomeLav.getText().isEmpty()) {
					scrollPaneLav.setVisible(false);
				}
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}


	@SuppressWarnings("unchecked")
	private void listarClientes() {
	
		DefaultListModel<String> modelo = new DefaultListModel<>();
		listarClientes.setModel(modelo);

		String readLista = "select * from clientes where nome like '" + txtNomeCli.getText() + "%'" + "order by nome";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(readLista);
			rs = pst.executeQuery();
		
			while (rs.next()) {
				
				scrollPane.setVisible(true);
			
				modelo.addElement(rs.getString(2));
		
				if (txtNomeCli.getText().isEmpty()) {
					scrollPane.setVisible(false);
				}
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}


	private void editarOS() {


		if (txtCor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a cor!");
			txtCor.requestFocus();

		} else if (txtPlaca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a placa!!");
			txtPlaca.requestFocus();

		} else if (txtModelo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o modelo do veiculo!");
			txtModelo.requestFocus();

		} else {

			String update = "update servicos set corveiculo=?,placaveiculo=?,modeloveiculo=?,tipodelavagem=?,valor=?,observacao=?,idcli=?,idlav=?,usuario=? where os=? ";
			try {
				con = dao.conectar();

				pst = con.prepareStatement(update);

				pst.setString(1, txtCor.getText());
				pst.setString(2, txtPlaca.getText());
				pst.setString(3, txtModelo.getText());
				pst.setString(4, cboLavagem.getSelectedItem().toString());
				pst.setString(5, txtValor.getText());
				pst.setString(6, txtObservacao.getText());
				pst.setString(7, txtIDCli.getText());
				pst.setString(8, txtIDLav.getText());
				pst.setString(9, txtUsuario.getText());
				pst.setString(10, txtOS.getText());

				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Dados da Ordem Serviço alterados com sucesso!");
				con.close();
				Limpar();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}



	private void excluirOS() { 

		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste usuário?", "ATENÇÃO!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from servicos where idcli=?";
			try {

				con = dao.conectar();

				pst = con.prepareStatement(delete);
				pst.setString(1, txtIDCli.getText());
				pst.executeUpdate();

				Limpar();
				JOptionPane.showMessageDialog(null, "OS excluída");

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}


	private void imprimirOS() {
	
		Document document = new Document();
	
		try {
		
			PdfWriter.getInstance(document, new FileOutputStream("os.pdf"));
		
			document.open();
			String readOS = "select servicos.os,servicos.placaveiculo,servicos.modeloveiculo,servicos.corveiculo,servicos.tipodelavagem,servicos.valor, clientes.nome as cliente, clientes.telefone from servicos inner join clientes on servicos.idcli = clientes.idcli inner join lavadores on servicos.idlav = lavadores.idlav where os =?;";

			try {
				
				con = dao.conectar();
			
				pst = con.prepareStatement(readOS);
				pst.setString(1, txtOS.getText());
		
				rs = pst.executeQuery();
			
				if (rs.next()) {
					
					document.add(new Paragraph(" "));

					document.add(new Paragraph(" "));
					
					
					
					
					document.add(new Paragraph(" "));
					document.add(new Paragraph(" "));


					
					document.add(new Paragraph("_____________________________________________________________________________"));
					
					document.add(new Paragraph(" "));
					
					Paragraph cliente = new Paragraph("Cliente: " + rs.getString(7));
					cliente.setAlignment(Element.ALIGN_CENTER);
					document.add(cliente);
					
					document.add(new Paragraph(" "));
					

					Paragraph telefone = new Paragraph("Telefone: " + rs.getString(8));
					telefone.setAlignment(Element.ALIGN_CENTER);
					document.add(telefone);
					

					
					document.add(new Paragraph(" "));
				
					
					document.add(new Paragraph("---------------------------------------------- (RECIBO DE SERVIÇOS) ---------------------------------------------"));
					
					document.add(new Paragraph(" "));
					
					Paragraph ticket = new Paragraph("Ticket: " + rs.getString(1));
					ticket.setAlignment(Element.ALIGN_CENTER);
					document.add(ticket);

					
					document.add(new Paragraph(" "));
					
					Paragraph placa = new Paragraph("Placa: " + rs.getString(2));
					placa.setAlignment(Element.ALIGN_CENTER);
					document.add(placa);
					
					document.add(new Paragraph(" "));
					
					
					Paragraph modelo = new Paragraph("Modelo: " + rs.getString(3));
					modelo.setAlignment(Element.ALIGN_CENTER);
					document.add(modelo);
					
					document.add(new Paragraph(" "));
					
					Paragraph tipolavagem = new Paragraph("Tipo de lavagem: " + rs.getString(5));
					tipolavagem.setAlignment(Element.ALIGN_CENTER);
					document.add(tipolavagem);
					
					document.add(new Paragraph(" "));
					
					document.add(new Paragraph("------------------------------------------------------- (EXTRATO) -------------------------------------------------------"));
					
					document.add(new Paragraph(" "));
					
					Paragraph valor = new Paragraph("Valor total: " + rs.getString(6));
					valor.setAlignment(Element.ALIGN_CENTER);
					document.add(valor);
					
				
					Image imagem = Image.getInstance(Servicos.class.getResource("/img/logo-2.jpg"));
					imagem.scaleToFit(256, 256);
					imagem.setAbsolutePosition(180, 630);
					document.add(imagem);
					
				}
				
				
			
				con.close();

			} catch (Exception e) {
				System.out.println(e);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		document.close();

		try {
			Desktop.getDesktop().open(new File("os.pdf"));
		} catch (Exception e) {
			System.out.println(e);
		}
	} 
	

	private void Limpar() {
		txtOS.setText(null);
		txtIDCli.setText(null);
		txtCor.setText(null);
		txtPlaca.setText(null);
		txtModelo.setText(null);
		txtObservacao.setText(null);
		cboLavagem.setSelectedItem("");
		txtDataOS.setDate(null);
		txtValor.setText(null);
		txtIDCli.setText(null);
		txtNomeCli.setText(null);
		txtNomeLav.setText(null);
		txtIDLav.setText(null);

		btnAdicionar.setEnabled(false);
		btnEditar.setEnabled(false);
		btnExcluir.setEnabled(false);
		btnOSI.setEnabled(false);

	}

	

	private void recuperarOS() {
		String readOS = "select max(os) from servicos";

		try {
			con = dao.conectar();
			pst = con.prepareStatement(readOS);
			rs = pst.executeQuery();
			if (rs.next()) {
				txtOS.setText(rs.getNString(1));

			} else {
				JOptionPane.showMessageDialog(null, "OS inexistente");
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
