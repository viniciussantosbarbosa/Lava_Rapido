package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import com.toedter.calendar.JDateChooser;

import model.DAO;
import util.Validador;
import java.awt.Toolkit;

@SuppressWarnings("serial")
public class Produtos extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtFornecedor;
	private JTextField txtIDfor;
	private JTextField txtNomeProd;
	private JTextField txtDescricao;
	private JTextField txtCod;
	private JTextField txtLocal;
	private JTextField txtQuant;
	private JTextField txtQuantMin;
	private JTextField txtValor;
	private JTextField txtIDprod;
	
	DAO dao = new DAO();
	private Connection con;
	private ResultSet rs;
	private PreparedStatement pst;
	@SuppressWarnings("rawtypes")
	private JComboBox cboTipo;
	private JDateChooser txtDataEntrada;
	private JDateChooser txtValidade;
	private JButton btnAdicionar;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JButton btnLimpar;
	@SuppressWarnings("rawtypes")
	private JList listarFornecedores;
	private JScrollPane scrollPaneFor;
	private JScrollPane scrollPane;
	private JScrollPane scrollPaneprod;
	@SuppressWarnings("rawtypes")
	private JList listarProdutos;


	public static void main(String[] args) {
		try {
			Produtos dialog = new Produtos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Produtos() {
		setTitle("Lava Rápido Vinicius - Produtos");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Produtos.class.getResource("/img/carro pqn.png")));
		setBounds(100, 100, 567, 531);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("IDProd:");
			lblNewLabel.setBounds(10, 11, 46, 14);
			contentPanel.add(lblNewLabel);
		}
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Fornecedor", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 36, 531, 76);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		scrollPaneFor = new JScrollPane();
		scrollPaneFor.setVisible(false);
		scrollPaneFor.setBounds(87, 36, 150, 76);
		panel.add(scrollPaneFor);
		
		listarFornecedores = new JList();
		scrollPaneFor.setViewportView(listarFornecedores);
		listarFornecedores.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarFornecedoresLista();
			}
		});
		scrollPaneFor.setViewportView(listarFornecedores);
		
		JLabel lblNewLabel_1 = new JLabel("Fornecedor:");
		lblNewLabel_1.setBounds(10, 22, 84, 14);
		panel.add(lblNewLabel_1);
		
		txtFornecedor = new JTextField();
		txtFornecedor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				listarFornecedores();
			}
			@Override
			public void keyTyped(KeyEvent e) {
			
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtFornecedor.setBounds(87, 19, 150, 20);
		panel.add(txtFornecedor);
		txtFornecedor.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("IDfor:");
		lblNewLabel_2.setBounds(265, 22, 46, 14);
		panel.add(lblNewLabel_2);
		
		txtIDfor = new JTextField();
		txtIDfor.setEditable(false);
		txtIDfor.setBounds(303, 19, 84, 20);
		panel.add(txtIDfor);
		txtIDfor.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Nome do produto", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(10, 112, 531, 107);
		contentPanel.add(panel_1);
		panel_1.setLayout(null);
		
		txtNomeProd = new JTextField();
		txtNomeProd.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				listarProdutos();
			}
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		
		
		scrollPaneprod = new JScrollPane();
		scrollPaneprod.setVisible(false);
		scrollPaneprod.setBounds(10, 57, 484, 41);
		panel_1.add(scrollPaneprod);
		
		listarProdutos = new JList();
		
		listarProdutos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarProdutosLista();
			}
		});
		scrollPaneprod.setViewportView(listarProdutos);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 97, 484, -40);
		panel_1.add(scrollPane);
		txtNomeProd.setBounds(10, 22, 484, 35);
		panel_1.add(txtNomeProd);
		txtNomeProd.setColumns(10);
		txtNomeProd.setDocument (new Validador(30));
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarProdutos();
			}	
		});
		
		btnNewButton.setBorder(null);
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.setIcon(new ImageIcon(Produtos.class.getResource("/img/search pqn.png")));
		btnNewButton.setBounds(493, 11, 38, 48);
		panel_1.add(btnNewButton);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "Descri\u00E7\u00E3o", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_2.setBounds(10, 216, 531, 87);
		contentPanel.add(panel_2);
		panel_2.setLayout(null);
		
		txtDescricao = new JTextField();
		txtDescricao.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {

				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtDescricao.setBounds(10, 21, 484, 55);
		panel_2.add(txtDescricao);
		txtDescricao.setColumns(10);
		txtDescricao.setDocument (new Validador(30));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(null, "cod.bar", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_3.setBounds(20, 300, 88, 49);
		contentPanel.add(panel_3);
		panel_3.setLayout(null);
		
		txtCod = new JTextField();
		txtCod.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {

				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtCod.setBounds(10, 21, 68, 20);
		panel_3.add(txtCod);
		txtCod.setColumns(10);
		txtCod.setDocument (new Validador(15));
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(null, "Local", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_4.setBounds(118, 300, 78, 49);
		contentPanel.add(panel_4);
		panel_4.setLayout(null);
		
		txtLocal = new JTextField();
		txtLocal.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321()-.";
				if (caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtLocal.setBounds(10, 21, 58, 20);
		panel_4.add(txtLocal);
		txtLocal.setColumns(10);
		txtLocal.setDocument (new Validador(30));
			
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Quant.", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_5.setBounds(203, 300, 77, 49);
		contentPanel.add(panel_5);
		panel_5.setLayout(null);
		
		txtQuant = new JTextField();
		txtQuant.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
		
				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtQuant.setBounds(10, 21, 57, 20);
		panel_5.add(txtQuant);
		txtQuant.setColumns(10);
		txtQuant.setDocument (new Validador(30));
		
		cboTipo = new JComboBox();
		cboTipo.setModel(new DefaultComboBoxModel(new String[] {"", "KG", "M", "G", "PC", "CX", "L", "ML"}));
		cboTipo.setBounds(290, 311, 66, 31);
		contentPanel.add(cboTipo);
		
		txtValidade = new JDateChooser();
		txtValidade.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				
			}
		});
		txtValidade.setBounds(70, 383, 131, 20);
		contentPanel.add(txtValidade);
		
		JLabel lblNewLabel_3 = new JLabel("Validade:");
		lblNewLabel_3.setBounds(10, 383, 66, 14);
		contentPanel.add(lblNewLabel_3);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new TitledBorder(null, "Quant.min", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_6.setBounds(222, 366, 82, 49);
		contentPanel.add(panel_6);
		panel_6.setLayout(null);
		
		txtQuantMin = new JTextField();
		txtQuantMin.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
	
					String caracteres = "0987654321";
					if (!caracteres.contains(e.getKeyChar() + "")) {
						e.consume();
					}
	
				
			}
		});
		txtQuantMin.setBounds(10, 19, 62, 19);
		panel_6.add(txtQuantMin);
		txtQuantMin.setColumns(10);
		
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new TitledBorder(null, "Valor", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_7.setBounds(314, 366, 88, 49);
		contentPanel.add(panel_7);
		panel_7.setLayout(null);
		
		txtValor = new JTextField();
		txtValor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {

				String caracteres = "0987654321()-.";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtValor.setBounds(10, 21, 68, 20);
		panel_7.add(txtValor);
		txtValor.setColumns(10);
		txtValor.setDocument (new Validador(10));
		
		btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarProduto();
			}
		});
		btnAdicionar.setBorder(null);
		btnAdicionar.setContentAreaFilled(false);
		btnAdicionar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAdicionar.setIcon(new ImageIcon(Produtos.class.getResource("/img/adicionar.png")));
		btnAdicionar.setBounds(78, 434, 48, 48);
		contentPanel.add(btnAdicionar);
		
		btnEditar = new JButton("");
		btnEditar.setEnabled(false);
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarProduto();
			}
		});
		btnEditar.setContentAreaFilled(false);
		btnEditar.setBorder(null);
		btnEditar.setIcon(new ImageIcon(Produtos.class.getResource("/img/editar.png")));
		btnEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnEditar.setBounds(136, 434, 48, 48);
		contentPanel.add(btnEditar);
		
		btnExcluir = new JButton("");
		btnExcluir.setEnabled(false);
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirProduto();
			}
		});
		btnExcluir.setContentAreaFilled(false);
		btnExcluir.setBorder(null);
		btnExcluir.setIcon(new ImageIcon(Produtos.class.getResource("/img/excluir contato.png")));
		btnExcluir.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnExcluir.setBounds(194, 434, 48, 48);
		contentPanel.add(btnExcluir);
		
		btnLimpar = new JButton("");
		btnLimpar.setEnabled(false);
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpar();
			}
		});
		btnLimpar.setContentAreaFilled(false);
		btnLimpar.setBorder(null);
		btnLimpar.setIcon(new ImageIcon(Produtos.class.getResource("/img/limpar (2).png")));
		btnLimpar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimpar.setBounds(290, 434, 48, 48);
		contentPanel.add(btnLimpar);
		
		txtDataEntrada = new JDateChooser();
		txtDataEntrada.setEnabled(false);
		txtDataEntrada.setBounds(370, 5, 139, 20);
		contentPanel.add(txtDataEntrada);
		
		JLabel lblNewLabel_4 = new JLabel("Data Entrada:");
		lblNewLabel_4.setBounds(290, 5, 79, 20);
		contentPanel.add(lblNewLabel_4);
		
		txtIDprod = new JTextField();
		txtIDprod.setToolTipText("");
		txtIDprod.setEditable(false);
		txtIDprod.setBounds(60, 8, 66, 20);
		contentPanel.add(txtIDprod);
		txtIDprod.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
	
	
	private void adicionarProduto() {


		if (txtNomeProd.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o nome do produto!");
			txtNomeProd.requestFocus();
		} else if (txtDescricao.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a descrição do produto!");
			txtDescricao.requestFocus();
		} else if (txtCod.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o codigo do produto!");
			txtCod.requestFocus();
		} else if (txtLocal.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o local de armazenagem do produto!");
			txtLocal.requestFocus();
		} else if (txtQuant.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a quantidade!");
			txtQuant.requestFocus();
		} else {

		
			String create = "insert into produtos (nomeproduto,descricao,codigo,loc,quant,tipo,datasaida,quantminima,valor) values (?,?,?,?,?,?,?,?,?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);

				pst.setString(1, txtNomeProd.getText());
				pst.setString(2, txtDescricao.getText());
				pst.setString(3, txtCod.getText());
				pst.setString(4, txtLocal.getText());
				pst.setString(5, txtQuant.getText());
				pst.setString(6, cboTipo.getSelectedItem().toString());
			

				SimpleDateFormat formatador = new SimpleDateFormat("yyyyMMdd");

				if (txtValidade.getDate() == null) {

				pst.setString(7, null);

				} else {

				String dataFormatada = formatador.format(txtValidade.getDate());

				pst.setString(7, dataFormatada);

				}
				

				if (txtDataEntrada.getDate() == null) {

				pst.setString(8, null);

				} else {

				String dataFormatada1 = formatador.format(txtValidade.getDate());

				pst.setString(8, dataFormatada1);

				}
				
				pst.setString(8, txtQuantMin.getText());
				pst.setString(9, txtValor.getText());
				pst.executeUpdate();

				
				JOptionPane.showMessageDialog(null, "Produto registrado com susesso!");
				
		
				Limpar();
				con.close();
			
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		

		
		
	}


private void buscarProdutos() {

	String read = "select * from produtos where nomeproduto = ?";
	try {
	
		con = dao.conectar();
		pst = con.prepareStatement(read);
		pst.setString(1, txtNomeProd.getText());
		rs = pst.executeQuery();
		if (rs.next()) {
			
			txtIDprod.setText(rs.getString(1));
			txtNomeProd.setText(rs.getString(2));
			txtDescricao.setText(rs.getString(3));
			txtCod.setText(rs.getString(4));
			txtLocal.setText(rs.getString(5));
			txtQuant.setText(rs.getString(6));
			cboTipo.setSelectedItem(rs.getString(7));
			
		
			String setarData1 = rs.getString(8);
			
			
			Date dataFormatada = new SimpleDateFormat("yyyy-MM-dd").parse(setarData1);
			txtDataEntrada.setDate(dataFormatada);
			
		
			String setarData2 = rs.getString(9);
		
			Date dataFormatada2 = new SimpleDateFormat("yyyy-MM-dd").parse(setarData2);
			txtValidade.setDate(dataFormatada2);
	
			txtQuantMin.setText(rs.getString(10));
			txtValor.setText(rs.getString(11));
			txtIDfor.setText(rs.getString(12));

			btnAdicionar.setEnabled(false);
			btnEditar.setEnabled(true);
			btnExcluir.setEnabled(true);

		} else {
			JOptionPane.showMessageDialog(null, "Produto não existe!");
			btnAdicionar.setEnabled(true);
		}

		con.close();
	} catch (Exception e) {
		System.out.println(e);
	}
}

private void buscarFornecedoresLista() {
	
	int linha = listarFornecedores.getSelectedIndex();
	
	if (linha >= 0) {
		System.out.println(linha);
		
		String read2 = "select * from fornecedores where razao like '" + txtFornecedor.getText() + "%'"
				+ "order by razao limit " + (linha) + " , 1";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(read2);
			rs = pst.executeQuery();
			if (rs.next()) {
			
				scrollPaneFor.setVisible(false);

				txtIDfor.setText(rs.getString(1));
				txtFornecedor.setText(rs.getString(2));

				

			} else {
				System.out.println("Fornecedor não cadastrado");
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	} else {
	
		scrollPaneFor.setVisible(false);
	}
}


@SuppressWarnings("unchecked")
private void listarFornecedores() {

	DefaultListModel<String> modelo = new DefaultListModel<>();
	listarFornecedores.setModel(modelo);

	String readLista = "select * from fornecedores where razao like '" + txtFornecedor.getText() + "%'" + "order by razao";
	try {
		con = dao.conectar();
		pst = con.prepareStatement(readLista);
		rs = pst.executeQuery();
		
		while (rs.next()) {
			
			scrollPaneFor.setVisible(true);
		
			modelo.addElement(rs.getString(2));
			
			if (txtFornecedor.getText().isEmpty()) {
				scrollPaneFor.setVisible(false);
			}
		}
		con.close();
	} catch (Exception e) {
		System.out.println(e);
	}
}


 @SuppressWarnings("unchecked")
private void listarProdutos() {

	DefaultListModel<String> modelo = new DefaultListModel<>();
	listarProdutos.setModel(modelo);

	String readLista = "select * from produtos where nomeproduto like '" + txtNomeProd.getText() + "%'" + "order by nomeproduto";
	try {
		con = dao.conectar();
		pst = con.prepareStatement(readLista);
		rs = pst.executeQuery();

		while (rs.next()) {
		
			scrollPaneprod.setVisible(true);
		
			modelo.addElement(rs.getString(2));
		
			if (txtNomeProd.getText().isEmpty()) {
				scrollPaneprod.setVisible(false);
			}
		}
		con.close();
	} catch (Exception e) {
		System.out.println(e);
	}
}
 
 private void buscarProdutosLista() {
	
		int linha = listarProdutos.getSelectedIndex();
		
		if (linha >= 0) {
			System.out.println(linha);
			String read2 = "select * from produtos where nomeproduto like '" + txtNomeProd.getText() + "%'"
					+ "order by nomeproduto limit " + (linha) + " , 1";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(read2);
				rs = pst.executeQuery();
				if (rs.next()) {
				
					scrollPaneprod.setVisible(false);

					txtIDprod.setText(rs.getString(1));
					txtNomeProd.setText(rs.getString(2));
					txtDescricao.setText(rs.getString(3));
					txtCod.setText(rs.getString(4));
					txtLocal.setText(rs.getString(5));
					txtQuant.setText(rs.getString(6));
					cboTipo.setSelectedItem(rs.getString(7));
					
					
					String setarData1 = rs.getString(8);
				
					Date dataFormatada = new SimpleDateFormat("yyyy-MM-dd").parse(setarData1);
					txtDataEntrada.setDate(dataFormatada);
					
			
					String setarData2 = rs.getString(9);

					Date dataFormatada2 = new SimpleDateFormat("yyyy-MM-dd").parse(setarData2);
					txtValidade.setDate(dataFormatada2);
					
					txtQuantMin.setText(rs.getString(10));
					txtValor.setText(rs.getString(11));
					
					btnAdicionar.setEnabled(false);
					btnEditar.setEnabled(true);
					btnExcluir.setEnabled(true);
					btnLimpar.setEnabled(true);
					

				} else {
					System.out.println("Produto não cadastrado");
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		} else {
	
			scrollPaneFor.setVisible(false);
		}
	}


private void editarProduto() {


	if (txtNomeProd.getText().isEmpty()) {
		JOptionPane.showMessageDialog(null, "Informe a cor!");
		txtNomeProd.requestFocus();

	} else if (txtDescricao.getText().isEmpty()) {
		JOptionPane.showMessageDialog(null, "Informe a placa!!");
		txtDescricao.requestFocus();

	} else if (txtCod.getText().isEmpty()) {
		JOptionPane.showMessageDialog(null, "Informe o modelo do veiculo!");
		txtCod.requestFocus();

	} else {

		String update = "update produtos set nomeproduto=?,descricao=?,codigo=?,loc=?,quant=?,tipo=?,datasaida=?,quantminima=?,valor=? where idprod=? ";
		try {
			con = dao.conectar();

			pst = con.prepareStatement(update);

			pst.setString(1, txtNomeProd.getText());
			pst.setString(2, txtDescricao.getText());
			pst.setString(3, txtCod.getText());
			pst.setString(4, txtLocal.getText());
			pst.setString(5, txtQuant.getText());
			pst.setString(6, cboTipo.getSelectedItem().toString());	
			
			SimpleDateFormat formatador = new SimpleDateFormat("yyyyMMdd");

			if (txtValidade.getDate() == null) {

			pst.setString(7, null);

			} else {

			String dataFormatada = formatador.format(txtValidade.getDate());

			pst.setString(7, dataFormatada);

			}
			pst.setString(8, txtQuantMin.getText());
			pst.setString(9, txtValor.getText());
			pst.setString(10, txtIDprod.getText());
		

			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Dados do produto editados com sucesso!");
			con.close();
			Limpar();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}

private void excluirProduto() { 

	int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste produto?", "ATENÇÃO!",
			JOptionPane.YES_NO_OPTION);
	if (confirma == JOptionPane.YES_OPTION) {
		String delete = "delete from produtos where idprod=?";
		try {

			con = dao.conectar();

			pst = con.prepareStatement(delete);
			pst.setString(1, txtIDprod.getText());
			pst.executeUpdate();

			Limpar();
			JOptionPane.showMessageDialog(null, "Produto excluído");

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

private void Limpar() {
	txtNomeProd.setText(null);
	txtDescricao.setText(null);
	txtCod.setText(null);
	txtLocal.setText(null);
	txtQuant.setText(null);
	txtDescricao.setText(null);
	cboTipo.setSelectedItem("");
	txtQuantMin.setText(null);
	txtValor.setText(null);
	txtValidade.setDate(null);
	txtDataEntrada.setDate(null);
	txtIDprod.setText(null);
	txtFornecedor.setText(null);
	txtIDfor.setText(null);


	btnAdicionar.setEnabled(false);
	btnEditar.setEnabled(false);
	btnExcluir.setEnabled(false);

}
}
