package view;

import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JDialog;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import model.DAO;
import java.awt.Toolkit;

@SuppressWarnings("serial")
public class Relatorios extends JDialog {
	
	
	DAO dao = new DAO();
	private Connection con;
	private ResultSet rs;
	private PreparedStatement pst;
	private JButton btnQuantidadeMin;

	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Relatorios dialog = new Relatorios();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public Relatorios() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Relatorios.class.getResource("/img/carro pqn.png")));
		setTitle("Lava Rápido Vinicius - Relatorios");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JButton btnRelClientes = new JButton("Clientes");
		btnRelClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				relatorioClientes();
			}
		});
		btnRelClientes.setBounds(46, 81, 154, 23);
		getContentPane().add(btnRelClientes);
		
		JButton btnVeiculos = new JButton("Veiculos");
		btnVeiculos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				relatorioVeiculos();
			}
		});
		btnVeiculos.setBounds(227, 81, 134, 23);
		getContentPane().add(btnVeiculos);
		
		btnQuantidadeMin = new JButton("Quantidade Minima");
		btnQuantidadeMin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				relatorioQuantMin();
			}
		});
		btnQuantidadeMin.setBounds(46, 130, 154, 23);
		getContentPane().add(btnQuantidadeMin);

	} 
	
	private void relatorioQuantMin() {
	
		Document document = new Document();
	
		document.setPageSize(PageSize.A4.rotate());
	
		try {
	
			PdfWriter.getInstance(document, new FileOutputStream("quantidade.pdf"));
		
			document.open();
			
			Date dataRelatorio = new Date();
			DateFormat formatador = DateFormat.getDateInstance(DateFormat.FULL);
			document.add(new Paragraph(formatador.format(dataRelatorio)));
	
			document.add(new Paragraph("QuantiadadeMin:"));
			document.add(new Paragraph (" "));
	
		
			String readQuantmin = "select produtos.idprod,produtos.nomeproduto,produtos.descricao,produtos.codigo,produtos.loc,produtos.quant,clientes.nome as cliente, clientes.telefone from produtos inner join clientes on produtos.idfor = produtos.idfor inner join fornecedores on produtos.idfor = produtos.idfor where quantminima >=quant;";
			try {
			
				con = dao.conectar();
			
				pst = con.prepareStatement(readQuantmin);
			
				rs = pst.executeQuery();
			
				PdfPTable tabela = new PdfPTable(4); 
				
				PdfPCell col1 = new PdfPCell(new Paragraph("Produto"));
				PdfPCell col2 = new PdfPCell(new Paragraph("Nome Produto"));
				PdfPCell col3 = new PdfPCell(new Paragraph("Descrição"));
				PdfPCell col4 = new PdfPCell(new Paragraph("código"));
				tabela.addCell(col1);
				tabela.addCell(col2);
				tabela.addCell(col3);
				tabela.addCell(col4);
				
				while (rs.next()) {
					
					tabela.addCell(rs.getString(1));
					tabela.addCell(rs.getString(2));
					tabela.addCell(rs.getString(3));
					tabela.addCell(rs.getString(4));
				}
				
				document.add(tabela);
		
			} catch (Exception e) {
				System.out.println(e);
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}

		document.close();

		try {
			Desktop.getDesktop().open(new File("quantidade.pdf"));
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		
	}
	
	private void relatorioClientes() {
	
		Document document = new Document();
	
		document.setPageSize(PageSize.A4.rotate());
	
		try {
		
			PdfWriter.getInstance(document, new FileOutputStream("clientes.pdf"));
	
			document.open();
			
			Date dataRelatorio = new Date();
			DateFormat formatador = DateFormat.getDateInstance(DateFormat.FULL);
			document.add(new Paragraph(formatador.format(dataRelatorio)));
			
			document.add(new Paragraph("Clientes:"));
			document.add(new Paragraph (" "));
	
			String readClientes = "select servicos.os,clientes.nome as cliente, clientes.telefone from servicos inner join clientes on servicos.idcli = clientes.idcli inner join lavadores on servicos.idlav = lavadores.idlav where os = 1;";
			try {
			
				con = dao.conectar();
			
				pst = con.prepareStatement(readClientes);
			
				rs = pst.executeQuery();
				
				PdfPTable tabela = new PdfPTable(3); 
				
				PdfPCell col1 = new PdfPCell(new Paragraph("OS"));
				PdfPCell col2 = new PdfPCell(new Paragraph("Cliente"));
				PdfPCell col3 = new PdfPCell(new Paragraph("Telefone"));
				tabela.addCell(col1);
				tabela.addCell(col2);
				tabela.addCell(col3);
	
				while (rs.next()) {
					
					tabela.addCell(rs.getString(1));
					tabela.addCell(rs.getString(2));
					tabela.addCell(rs.getString(3));
				}
				
				document.add(tabela);
			
			} catch (Exception e) {
				System.out.println(e);
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}

		document.close();

		try {
			Desktop.getDesktop().open(new File("clientes.pdf"));
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		
	}
	
	
	private void relatorioVeiculos() {
		

		Document document = new Document();
	
		document.setPageSize(PageSize.A4.rotate());

		try {
			
			PdfWriter.getInstance(document, new FileOutputStream("Veiculos.pdf"));
		
			document.open();
	
			Date dataRelatorio = new Date();
			DateFormat formatador = DateFormat.getDateInstance(DateFormat.FULL);
			document.add(new Paragraph(formatador.format(dataRelatorio)));
		
			document.add(new Paragraph("Veiculos:"));
			document.add(new Paragraph(" ")); 
	
			String readVeiculos = "select servicos.os,servicos.placaveiculo,servicos.modeloveiculo,servicos.corveiculo,servicos.tipodelavagem,servicos.valor,clientes.nome as cliente, clientes.telefone from servicos inner join clientes on servicos.idcli = clientes.idcli inner join lavadores on servicos.idlav = lavadores.idlav;";
			try {
				
				con = dao.conectar();
			
				pst = con.prepareStatement(readVeiculos);
	
				rs = pst.executeQuery();
			
				PdfPTable tabela = new PdfPTable(8); 
				
				
				PdfPCell col1 = new PdfPCell(new Paragraph("Os"));
				PdfPCell col2 = new PdfPCell(new Paragraph("Placa"));
				PdfPCell col3 = new PdfPCell(new Paragraph("Modelo Veiculo"));
				PdfPCell col4 = new PdfPCell(new Paragraph("Cor Veiculo"));
				PdfPCell col5 = new PdfPCell(new Paragraph("Tipo de lavagem"));
				PdfPCell col6 = new PdfPCell(new Paragraph("Valor"));
				PdfPCell col7 = new PdfPCell(new Paragraph("Cliente"));
				PdfPCell col8 = new PdfPCell(new Paragraph("Telefone"));
			
				
				tabela.addCell(col1);
				tabela.addCell(col2);
				tabela.addCell(col3);
				tabela.addCell(col4);
				tabela.addCell(col5);
				tabela.addCell(col6);
				tabela.addCell(col7);
				tabela.addCell(col8);
			
				
				while (rs.next()) {
				
					tabela.addCell(rs.getString(1));
					tabela.addCell(rs.getString(2));
					tabela.addCell(rs.getString(3));
					tabela.addCell(rs.getString(4));
					tabela.addCell(rs.getString(5));
					tabela.addCell(rs.getString(6));
					tabela.addCell(rs.getString(7));
					tabela.addCell(rs.getString(8));
				}				
			
				document.add(tabela);
		
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		document.close();

		try {
			Desktop.getDesktop().open(new File("Veiculos.pdf"));
		} catch (Exception e) {
			System.out.println(e);
		}		
	}
}


